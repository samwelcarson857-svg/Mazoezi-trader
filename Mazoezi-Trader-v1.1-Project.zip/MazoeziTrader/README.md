# Mazoezi Trader — Version 1.1.0

An Android WebView learning simulator for beginners interested in the Nairobi Securities Exchange (NSE). The app uses **fictional illustrative prices and virtual KSh 100,000**. It does not connect to NSE, any broker, M-Pesa, a bank, or a live market-data feed. It does not execute real orders.

## Included features
- Mobile-first Android app and standalone HTML version
- NSE-focused example watchlist: Safaricom, KCB, Equity Group, Co-operative Bank, EABL and BAT Kenya
- Virtual cash balance and simulated buy/sell transactions
- Average entry price, open positions, portfolio value and unrealised practice P/L
- Local practice history saved on the device
- Searchable example-share list
- Beginner lessons and a three-question knowledge check
- Privacy and financial-safety notices
- GitHub Actions workflow that builds a **debug/test APK**

## Important limitations
This is a prototype for education only. All prices and percentage changes are made-up examples, not live, delayed or historical NSE data. There is no real-money trading, broker API, login, cloud synchronisation, payment system, or guaranteed income. Local practice data may be lost if app storage is cleared or the app is uninstalled.

Before adding real trading, market data, financial advice or paid broker referrals, confirm the regulatory position with Kenya's Capital Markets Authority (CMA), work with an appropriately licensed broker, obtain any required approvals, and implement appropriate security, privacy and legal controls. A broker partnership does not automatically remove the app owner's regulatory obligations.

## Build a test APK using GitHub Actions
1. Create a GitHub repository. Upload the **contents** of this folder, including the hidden `.github/workflows` directory.
2. Open the repository's **Actions** tab.
3. Select **Build Mazoezi Trader APK** and click **Run workflow**, or push to `main`/`master`.
4. When the run succeeds, open it and download the `Mazoezi-Trader-TEST-APK` artifact.
5. Extract the downloaded artifact ZIP to get `Mazoezi-Trader-TEST.apk`, transfer it to your Android phone and install it. You may need to allow installation from that source.

The APK from this workflow is for testing only. It is not a signed production release and is not ready for Play Store publication. This workspace cannot confirm the cloud build succeeds until the workflow is run on GitHub.

## Build locally
Requires Android SDK, Java 17 and Gradle 8.9. From this directory:

```sh
cd android
gradle assembleDebug
```

Expected output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Play Store and real trading readiness
Before a public release, check the current Google Play target API, developer-account and financial-features requirements. Google may require an organisation account and verification for financial-services apps. Prepare an accurate privacy policy, Data safety declaration, support contact, store listing and testing plan. Do not publish a real-trading feature until its regulatory and broker requirements have been confirmed.
